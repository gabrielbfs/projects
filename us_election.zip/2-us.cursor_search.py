# -*- coding: utf-8 -*-
"""
Created on Fri Jan 31 21:27:00 2020

@author: gabrielbustamante
"""

import sys
sys.path.append('C:/Users/gabri/Desktop/us elections')

from Twitter_API import Twitter_API

from datetime import datetime, timedelta
import time

from private import keys_v02 as private

import winsound


start = str(datetime.today().date() - timedelta(days=1))
end = str(datetime.today().date())
'''
start = '2020-01-27'
end = '2020-01-28'
'''

keys = {'TWITTER_APP_KEY':private['TWITTER_APP_KEY'], 
        'TWITTER_APP_SECRET':private['TWITTER_APP_SECRET'], 
        'TWITTER_KEY':private['TWITTER_KEY'], 
        'TWITTER_SECRET':private['TWITTER_SECRET']}


candidate = 'Bernie Sanders'
screen_name = 'to:BernieSanders -filter:retweets'
table = 'tweets_at_berniesanders'

print('#'*25)
print(candidate)
print('start: {}\nend: {}'.format(start, end))

at_candidate = Twitter_API(database='us_election', table=table, keys=keys)
at_candidate.cursor_search(screen_name=screen_name, candidate=candidate, 
                           since=start, until=end)

print('done')
winsound.PlaySound('SystemExclamation', winsound.SND_ALIAS)
winsound.PlaySound('SystemExclamation', winsound.SND_ALIAS)
winsound.PlaySound('SystemExclamation', winsound.SND_ALIAS)
print('#'*25)


candidate = 'Amy Klobuchar'
screen_name = 'to:amyklobuchar -filter:retweets'
table = 'tweets_at_amyklobuchar'

print('#'*25)
print(candidate)
print('start: {}\nend: {}'.format(start, end))

at_candidate = Twitter_API(database='us_election', table=table, keys=keys)
at_candidate.cursor_search(screen_name=screen_name, candidate=candidate, 
                           since=start, until=end)

print('done')
winsound.PlaySound('SystemExclamation', winsound.SND_ALIAS)
winsound.PlaySound('SystemExclamation', winsound.SND_ALIAS)
winsound.PlaySound('SystemExclamation', winsound.SND_ALIAS)
print('#'*25)
