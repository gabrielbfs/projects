# -*- coding: utf-8 -*-
"""
Created on Sat Jan 25 15:32:17 2020
@author: gabrielbustamante
"""

#########################
#########################
#########################
# Twitter KEYS V01
keys_v01 = {
            'TWITTER_APP_KEY':'CsL7j61NTSznXkdjO1flBGEAe',
            'TWITTER_APP_SECRET':'uic3CUvngrruoMZw6cz2Z6zFA6Ph3pqrBPJb5aupJiWnzhwUf6',
            'TWITTER_KEY':'1217885778644291585-Tnk8fqH3QPOtAmM7uZEUrXWnn7jUVv',
            'TWITTER_SECRET':'i7zz2FlmYF9rOuN1jIIRPKHEbGDa6b2j7eelxMzs9iIXX'
           }

#########################
#########################
#########################
# Twitter KEYS V02
keys_v02 = {
            'TWITTER_APP_KEY':'uC2yiK6gluL5Unc1U5WiOmTCB',
            'TWITTER_APP_SECRET':'D3fKuA5Cn6DCdnGBty5wfIRI08Cm9OfWgzvRjUti5wuuSTsbTj',
            'TWITTER_KEY':'1217885778644291585-nQmoO9dR9L3NDsNR888qurXnyc1QWA',
            'TWITTER_SECRET':'ghPgZ9zgkiUjMIK97AXCht55Jqu2ezlfsJhnRQIJ6MsL0'
           }
#########################
#########################
#########################
# Twitter KEYS V03
keys_v03 = {
            'TWITTER_APP_KEY':'G4a2kbntd2gpf5RX82qh99xkp',
            'TWITTER_APP_SECRET':'oEqzeQsKDKv951OUUp2ia79H8cExq7JuHWbgLT0BgTT8n9ES9j',
            'TWITTER_KEY':'1217885778644291585-dzM9DQDgCF6uXJ2HSIE9bkfBtsAFdr',
            'TWITTER_SECRET':'1bxyBVDl3St7f759CkMOQgSo5qoAG3zLbPnjhQe4XUNOt'
           }

#########################
#########################
#########################
# Twitter KEYS V04
keys_v04 = {
            'TWITTER_APP_KEY':'ovBwXELFJNar95lNQSRDvVC58',
            'TWITTER_APP_SECRET':'mw6loWyvEMOFJMgOZ7xNJ5ZGDHh9vp2LMgBjiBkLvgLkIsRMi4',
            'TWITTER_KEY':'1217885778644291585-5lnyhBrWgPr6ll0WxTNoFOV00xEtHR',
            'TWITTER_SECRET':'0SuCzkp3NvS9zbFep56lOgKK4eRSjyA7mgN5hvLaZqb54'
           }

#########################
#########################
#########################
# Twitter KEYS V05
keys_v05 = {
            'TWITTER_APP_KEY':'ZHL6E41YKbYTYsrZMwofKL6hl',
            'TWITTER_APP_SECRET':'AfLq2Xs981ft8CFYcZMJPGhdSVWe2zTniEi3dWZKvrfmOGPOyV',
            'TWITTER_KEY':'1217885778644291585-DRMlmWZUfUIaDq1z8jKcXKB3UYVeT2',
            'TWITTER_SECRET':'2sRbl1XlTR5fuFkKTxAI7gN8ZL5HqQM89oVGEkkcGnJ1f'
           }

#########################
#########################
#########################
# Twitter KEYS V06
keys_v06 = {
            'TWITTER_APP_KEY':'hhyvnIZsajy7cIMkMdt4aa8Pr',
            'TWITTER_APP_SECRET':'XbA8UHouTFhX02WPnoXYCAIb7P1vDhYnb7fmGPIs7kU9aNvgcR',
            'TWITTER_KEY':'1217885778644291585-2lml7sEx4BJIR5a1P6hBqPLh8U2guW',
            'TWITTER_SECRET':'yL4PCSPgsnt09TTJiYgBMxpo9cSuORI7JIDhZBuAx8aVp'
           }

#########################
#########################
#########################
# Twitter KEYS V07
keys_v07 = {
            'TWITTER_APP_KEY':'nymYJejg3T7FYzkUcyDlBT8Io',
            'TWITTER_APP_SECRET':'n3cZaZTXaCfL9OXrR4EE4GHKIcPde48CIQCXo631Otr46NXl97',
            'TWITTER_KEY':'1217885778644291585-F254XlZKKRT2JNmc2sI3rAOguujYJY',
            'TWITTER_SECRET':'h8oVYcyDUiyiSsKK4XgSNgliunPSAPCr1idZEB0tFUyWd'
           }

#########################
#########################
#########################
# Twitter KEYS V08
keys_v08 = {
            'TWITTER_APP_KEY':'M76KEWDIVmQoFfOTbSWpD23d1',
            'TWITTER_APP_SECRET':'wRjjZll37HSNih8iTGgJs2wIEfIRFOaLOaI8TejLor4NrwqBjG',
            'TWITTER_KEY':'1217885778644291585-9IfJxuKnXqYaF6rhOe0MxMsvqmX2bf',
            'TWITTER_SECRET':'ING0nqrvaM0n7oJ5rziDj0yP3aFgL492g22nap6iYQhzF'
           }

'''
#########################
#########################
#########################
# Twitter KEYS V09
keys_v09 = {
            'TWITTER_APP_KEY':'',
            'TWITTER_APP_SECRET':'',
            'TWITTER_KEY':'',
            'TWITTER_SECRET':''
           }
'''