# -*- coding: utf-8 -*-
"""
Created on Fri Jan 31 22:07:21 2020

@author: gabrielbustamante
"""
import sys
sys.path.append('C:/Users/gabri/Desktop/us elections')

import tweepy
from DataTwitter_json import DataTwitter_json

from sqlalchemy import create_engine, insert, Table, MetaData

import time

import pandas as pd


class Twitter_API(DataTwitter_json):
    
    def __init__(self, database, table, keys):
        print('-'*10)
        print('connected to mysql')
        
        self.path = 'mysql+pymysql://root:root@localhost:3306/' + database
        self.engine = create_engine(self.path)
        self.engine.connect()
        self.table = Table(table, MetaData(), autoload=True, autoload_with=self.engine)
        print('connected to api')
        self.auth = tweepy.OAuthHandler(keys['TWITTER_APP_KEY'], keys['TWITTER_APP_SECRET'])
        self.auth.set_access_token(keys['TWITTER_KEY'], keys['TWITTER_SECRET'])
        self.api = tweepy.API(self.auth, retry_count=50, retry_delay=300, timeout=180, wait_on_rate_limit=True)
        print('-'*10)
        
    
    '''
    def candidate_id(self, candidate):
        user = api.get_user(screen_name=candidate)
        return user.id
    
    def user_screen_name(self, user_id):
        user = api.get_user(id=user_id)
        return user.screen_name
    
    def candidate_total_followers(self, candidate):
        user = api.get_user(screen_name=candidate)  
        # user.friends_count
        return user.friends_count
    '''    
    
    def cursor_search(self, screen_name, candidate, since, until):
        verifier = True
        while verifier == True:
            try:
                verifier = True
                for data in tweepy.Cursor(self.api.search,  
                                          exclude_replies=False, 
                                          tweet_mode='extended', q=screen_name, 
                                          since=since, until=until, lang="en").items():
                             
                    stmt = DataTwitter_json()
                    stmt = stmt.set_stmt(data._json)
                    
                    stmt['candidate'] = candidate
                    
                    #print(json.dumps(stmt, indent = 4, sort_keys=True))
                    stmt = insert(self.table).values(stmt)
                    #self.engine.execute(stmt)
                    try:
                        self.engine.execute(stmt)
                    except:
                        pass
                verifier = False
                                    
            except tweepy.TweepError:
                verifier = True
                print('\nTweepError')
                print('\nsleeping . . .', end='') #, flush=True
                time.sleep(30)
                print('\nwaking up . . .', end='') #, flush=True
                print('\n')
                print('-'*10, end='')
                
            except tweepy.RateLimitError:
                verifier = True
                print('\nRateLimitError')
                print('\nsleeping . . .', end='') #, flush=True
                time.sleep(300)
                print('\nwaking up . . .', end='') #, flush=True
                print('\n')
                print('-'*10, end='')
                
        
                
    def cursor_search_geocode(self, screen_name, candidate, since, until):

        cities = pd.read_csv('C:/Users/gabri/Desktop/us elections/us_cities-889.csv', sep=';')
        
        for i in range(len(cities)):
            city = cities['city_ascii'].loc[i]
            state_id = cities['state_id'].loc[i]
            state_name = cities['state_name'].loc[i]
            
            lat = cities['lat'].loc[i]
            lng = cities['lng'].loc[i]
            geocode = str(lat) + ',' + str(lng) + ',25km'
            
            print('\r{}: {} - {}               \n'.format(i, state_id, city), end='')

            verifier = True
            while verifier == True:
                try:
                    verifier = True
                    for data in tweepy.Cursor(self.api.search,  
                                              exclude_replies=False, 
                                              tweet_mode='extended', q=screen_name, 
                                              since=since, until=until, lang="en", 
                                              geocode=geocode).items():
                                 
                        stmt = DataTwitter_json()
                        stmt = stmt.set_stmt(data._json)
                        
                        stmt['candidate'] = candidate
                        stmt['state_id'] = state_id
                        stmt['state_name'] = state_name
                        stmt['city'] = city
                        
                        #print(json.dumps(stmt, indent = 4, sort_keys=True))
                        stmt = insert(self.table).values(stmt)
                        #self.engine.execute(stmt)
                        try:
                            self.engine.execute(stmt)
                        except:
                            pass
                    verifier = False
                                        
                except tweepy.TweepError:
                    verifier = True
                    print('\nTweepError')
                    print('\nsleeping . . .', end='') #, flush=True
                    time.sleep(30)
                    print('\nwaking up . . .', end='') #, flush=True
                    print('\n')
                    print('-'*10, end='')
                    
                except tweepy.RateLimitError:
                    verifier = True
                    print('\nRateLimitError')
                    print('\nsleeping . . .', end='') #, flush=True
                    time.sleep(150)
                    print('\nwaking up . . .', end='') #, flush=True
                    print('\n')
                    print('-'*10, end='')
                
                
    
    def cursor_timeline(self, screen_name, candidate, since, until):
        verifier = True
        while verifier == True:
            try:
                verifier = True
                for data in tweepy.Cursor(self.api.search,  
                                          exclude_replies=False, 
                                          tweet_mode='extended', q=screen_name, 
                                          since=since, until=until, lang="en").items():
                             
                    stmt = DataTwitter_json()
                    stmt = stmt.set_stmt(data._json)
                    
                    stmt['candidate'] = candidate
                    
                    #print(json.dumps(stmt, indent = 4, sort_keys=True))
                    stmt = insert(self.table).values(stmt)
                    #self.engine.execute(stmt)
                    try:
                        self.engine.execute(stmt)
                    except:
                        pass
                verifier = False
                                    
            except tweepy.TweepError:
                verifier = True
                print('\nTweepError')
                print('\nsleeping . . .', end='') #, flush=True
                time.sleep(30)
                print('\nwaking up . . .', end='') #, flush=True
                print('\n')
                print('-'*10, end='')
                
            except tweepy.RateLimitError:
                verifier = True
                print('\nRateLimitError')
                print('\nsleeping . . .', end='') #, flush=True
                time.sleep(300)
                print('\nwaking up . . .', end='') #, flush=True
                print('\n')
                print('-'*10, end='')
    
    
