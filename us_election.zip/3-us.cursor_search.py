# -*- coding: utf-8 -*-
"""
Created on Fri Jan 31 21:27:00 2020

@author: gabrielbustamante
"""

import sys
sys.path.append('C:/Users/gabri/Desktop/us elections')

from Twitter_API import Twitter_API

from datetime import datetime, timedelta
import time

from private import keys_v03 as private

import winsound


start = str(datetime.today().date() - timedelta(days=1))
end = str(datetime.today().date())
'''
start = '2020-02-04'
end = '2020-02-05'
'''

keys = {'TWITTER_APP_KEY':private['TWITTER_APP_KEY'], 
        'TWITTER_APP_SECRET':private['TWITTER_APP_SECRET'], 
        'TWITTER_KEY':private['TWITTER_KEY'], 
        'TWITTER_SECRET':private['TWITTER_SECRET']}


candidate = 'Pete Buttigieg'
screen_name = 'to:PeteButtigieg -filter:retweets'
table = 'tweets_at_petebuttigieg'

print('#'*25)
print(candidate)
print('start: {}\nend: {}'.format(start, end))

at_candidate = Twitter_API(database='us_election', table=table, keys=keys)
at_candidate.cursor_search(screen_name=screen_name, candidate=candidate, 
                           since=start, until=end)

print('done')
winsound.PlaySound('SystemExclamation', winsound.SND_ALIAS)
winsound.PlaySound('SystemExclamation', winsound.SND_ALIAS)
winsound.PlaySound('SystemExclamation', winsound.SND_ALIAS)
print('#'*25)


candidate = 'Mike Bloomberg'
screen_name = 'to:MikeBloomberg -filter:retweets'
table = 'tweets_at_mikebloomberg'

print('#'*25)
print(candidate)
print('start: {}\nend: {}'.format(start, end))

at_candidate = Twitter_API(database='us_election', table=table, keys=keys)
at_candidate.cursor_search(screen_name=screen_name, candidate=candidate, 
                           since=start, until=end)

print('done')
winsound.PlaySound('SystemExclamation', winsound.SND_ALIAS)
winsound.PlaySound('SystemExclamation', winsound.SND_ALIAS)
winsound.PlaySound('SystemExclamation', winsound.SND_ALIAS)
print('#'*25)


'''
candidate = 'Andrew Yang'
screen_name = 'to:AndrewYang -filter:retweets'
table = 'tweets_at_andrewyang'

print('#'*25)
print(candidate)
print('start: {}\nend: {}'.format(start, end))

at_candidate = Twitter_API(database='us_election', table=table, keys=keys)
at_candidate.cursor_search(screen_name=screen_name, candidate=candidate, 
                           since=start, until=end)

print('done')
winsound.PlaySound('SystemExclamation', winsound.SND_ALIAS)
winsound.PlaySound('SystemExclamation', winsound.SND_ALIAS)
winsound.PlaySound('SystemExclamation', winsound.SND_ALIAS)
print('#'*25)
'''